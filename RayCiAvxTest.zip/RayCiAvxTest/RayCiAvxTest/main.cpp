#include "immintrin.h"
#include <limits>
#include <vector>
#include <iostream>

struct StatisticData
{
	int m_nSizeX;
	int m_nSizeY;
	float* m_pField;

	float m_fSum;
	float	m_fMean;
	float	m_fRMS;
	float	m_fVar;
	float	m_fStDev;
	float	m_fMin;
	float	m_fMax;
	bool	m_bValidStat;
};

//This is used to simulate a runtime check (that is not optimized away) if AVX is available.
//Since this function always returns "false", no AVX instruction should be executed during the runtime of this application.
__declspec(noinline)
bool is_avx_available() { return false; }


void calc_stat_results(StatisticData& data)
{
	data.m_fSum          = 0.f;
	data.m_fMean         = 0.f;
	data.m_fRMS          = 0.f;
	data.m_fVar          = 0.f;
	data.m_fStDev        = 0.f;
	data.m_fMin          = 0.f;
	data.m_fMax          = 0.f;
	data.m_bValidStat    = false;

	const int sizeX = data.m_nSizeX;
	const int sizeY = data.m_nSizeY;
	const int size  = sizeX * sizeY; //in this line, the application crashes on non-AVX-capable processors in win32 Release builds due to the AVX command "vmovups".

	if ( size > 0 )
	{
		int          idx   = 0;
		float* pField = data.m_pField;
		float        fMin  = std::numeric_limits<float>::max();
		float        fMax  = std::numeric_limits<float>::lowest();
		float        fSum  = 0.f;
		float        fRMS  = 0.f;

		if ( is_avx_available() )
		{
			__m256 min256 = _mm256_set1_ps( fMin );
			__m256 max256 = _mm256_set1_ps( fMax );
			__m256 sum256 = _mm256_setzero_ps();
			__m256 rms256 = _mm256_setzero_ps();

			for ( ; idx < size - ( 8 - 1 ); idx += 8 )
			{
				const __m256 val256 = _mm256_load_ps( pField + idx );
				max256              = _mm256_max_ps( max256, val256 );
				min256              = _mm256_min_ps( min256, val256 );
				sum256              = _mm256_add_ps( sum256, val256 );
				rms256              = _mm256_fmadd_ps( val256, val256, rms256 );
			}

			for ( int i = 0; i < 8; i++ )
			{
				const float minVal = min256.m256_f32[i];
				const float maxVal = max256.m256_f32[i];
				const float sumVal = sum256.m256_f32[i];
				const float rmsVal = rms256.m256_f32[i];
				if ( maxVal > fMax ) fMax = maxVal;
				if ( minVal < fMin ) fMin = minVal;
				fSum += sumVal;
				fRMS += rmsVal;
			}

			//If the following 3 lines would be excluded, the generated assembler code would not contain undesired AVX instructions
			for ( int i = 0; i < 8; i++ )
			{
				fSum += sum256.m256_f32[i];
			}
		}

		for ( ; idx < size; idx++ )
		{
			const float a = pField[idx];
			if ( a > fMax ) fMax = a;
			if ( a < fMin ) fMin = a;
			fSum += a;
			fRMS += a * a;
		}

		data.m_fMax = fMax;
		data.m_fMin = fMin;
		data.m_fSum = fSum;
		data.m_fRMS = fRMS;
	}

	const float fSize = (float) size;

	if ( size > 1 )
	{
		data.m_fVar   = ( data.m_fRMS - data.m_fSum * data.m_fSum / fSize ) / ( fSize - 1.f );
		data.m_fStDev = sqrt( data.m_fVar );
	}
	if ( size > 0 )
	{
		data.m_fRMS  = sqrt( data.m_fRMS / fSize );
		data.m_fMean = data.m_fSum / fSize;
	}
	data.m_bValidStat = true;
}


int main()
{
	std::vector<float> field(size_t(1000*1000));
	for (float& value : field)
		value = rand() / float(RAND_MAX);

	StatisticData data;
	data.m_nSizeX = 1000;
	data.m_nSizeY = 1000;
	data.m_pField = field.data();
	calc_stat_results(data);
	if (data.m_bValidStat)
	{
		std::cout << "And the results are: Min=" << data.m_fMin << ", Max=" << data.m_fMax << ", Mean=" << data.m_fMean << ", Sum=" << data.m_fSum << ", StdDev=" << data.m_fStDev << ", Var=" << data.m_fVar << ", RMS=" << data.m_fRMS << std::endl;
	}
	else
	{
		std::cout << "The results are not valid" << std::endl;
	}
}